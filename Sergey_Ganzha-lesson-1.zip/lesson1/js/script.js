// console.log('Привет');
// console.log(20);

// const x;
// x = 10;
// console.log(x);


// const y = 20;
// console.log(y);


// let my1020;
// let my_$;

// let camelCase = 20;
// let PascalCase = 30;
// let snake_case = 40;


// let x = 10, 
// 	y = 20, 
// 	z = 30;

// let g = 20;
// console.log(g);

// g = 450;
// console.log(g);



// let x = 20;
// let y = 'Привет';
// console.log(x);
// console.log(y);

// 20
// 20.333
// console.log(Infinity);
// console.log(-Infinity);
// console.log(NaN);


// let y = "Привет";
// console.log(y);
// y = 20;
// console.log(y);


// const x = 10;
// const y = 3;
// let c;
// c = x + y;
// console.log(c);
// c = x - y;
// console.log(c);
// c = x * y;
// console.log(c);
// c = x / y;
// console.log(c);

// c = 20 % 3;
// console.log(c);



// const x = "Привет ";
// const y = "Сергей";
// let c = x + y;
// console.log(c);


// const x = "10";
// const y = 5;
// console.log(+x + y);
// console.log(x - y);
// console.log(x / y);
// console.log(x * y);

// const x = '10';
// const y = 20;
// const z = 30;

// console.log(x + y + z);


// const x = '10';
// console.log(x);
// console.log(+x);

// const y = -20;
// console.log(y);
// console.log(-y);


// const x = '10.5050px';


// console.log(+x);
// console.log(parseInt(x));
// console.log(parseFloat(x));
// console.log(Number(x));



// const sun = true;
// const man = false;

// const x = 10;
// const y = 'hello';

// console.log(typeof sun);
// console.log(typeof x);
// console.log(typeof y);

// const a = 10;
// const b = 10;
// console.log(a > b);
// console.log(a < b);

// console.log(a >= b);
// console.log(a <= b);



// const a = 1;
// const b = false;

// console.log(a <= b);


// const x = 1;
// const y = '';

// console.log(x == y);


// const a = 'маша';
// const b = 'миша';
// const c = a == b;
// console.log(c);



// const x = 10;
// const y = 10;

// console.log(x != y);


// number
// string
// boolean
// undefined
// null

// let x;
// console.log(x);

// let x = null;



// преобразование к числу
// console.log(Number('  '));
// console.log(Number(false));
// console.log(Number(true));
// console.log(Number(undefined));
// console.log(Number(null));



//------------------------------------

// const x = 10;
// const y = 10;

// console.log('x == y', x == y); // нестрогое стравнение
// console.log('x != y', x != y); // нестрогое неравенство
// console.log('x === y', x === y); // строгое сравнение
// console.log('x !== y', x !== y); // строгое неравенство

// console.log(null == undefined);

// console.log(typeof null);
// console.log(typeof undefined);


// примитивные типы
// number
// BigInt
// string
// boolean
// undefined
// symbol

// особый тип
// null

// object




// let x = 0;
// let y = '';
// let z = null;
// let k = undefined;
// let f = NaN;




// console.log(!!x);
// console.log(!!y);
// console.log(!!z);
// console.log(!!k);
// console.log(!!f);



// console.log(Boolean(x));
// console.log(Boolean(y));
// console.log(Boolean(z));
// console.log(Boolean(k));
// console.log(Boolean(f));



//-------------------------------------------------


// const x = 20;
// const y = 20000;

// alert('hello ' + x + 'appel' + y);



// const result = prompt('Сколько вам лет?','18');
// console.log(result);


// const result = confirm('Вы уже уснули?');
// console.log(result);




// const result = parseInt(prompt('Сколько вам лет?','18'));
// console.log(result);

// const x = 10 + result;
// console.log(x);

///--------------------------------------------------------------
// Создайте переменную num и присвойте ей значение 10. 
// Выведите значение этой переменной на экран с помощью метода alert.


// const num = 10;
// alert(num);

//-----------------------------------------------------------------

// Написать программу, которая запросит у пользователя имя
// И выведет с помощью метода alert сообщение «Привет Имя!»
// const x = prompt('Enter name');
// alert('Привет ' + x + '!');


//-----------------------------------------------------------------

// Попросите пользователя ответить на вопрос «Вы сегодня обедали?» (используйте confirm)
// Выведите результат ответа в консоль

// const x = confirm('Вы сегодня обедали?');
// console.log(x);


//-----------------------------------------------------------------
// Попросите пользователя ввести число
// Прибавьте к этому числу переменную, заранее присвоив ей значение 10
// Затем отнимите 20
// Результат выведите в консоли

// const x = +prompt('ввести число','');
// const y = 10;
// const z = 20;
// console.log(x + y - z);


//-----------------------------------------------------------------
// Создайте две переменные
// x = 11
// y = '5'
// Выведите , сумму, разность, произведение, результат деления, остаток от деления.
// Каждое значение на новой строке.


// const x = 11;
// const y = '5';

// console.log(x + y);
// console.log(x - y);
// console.log(x / y);
// console.log(x * y);
// console.log(x % y);


//-----------------------------------------------------------------
// Создайте две переменные
// let x = 20;
// let y = 40;
// Выполните суммирование, результат запишите в переменную z
// Добавьте еще одну переменную k со значением '2'
// Сложите z и k
// Результат запишите в переменную result
// Выведите в консоль z и result

// const x = 20;
// const y = 40;

// const z = x + y;
// const k = '2';

// const result = z + +k;
// console.log(result);
// console.log(k);



//-----------------------------------------------------------------
// Рассчитайте объем цилиндра
// По формуле V = πr2h
// Необходимые данные запросите у пользователя 

// const pi = 3.14;
// const r = +prompt('Введите радиус');
// const h = +prompt('Введите высоту');
// console.log('объем цилиндра = ' + pi*r*r*h);




//-----------------------------------------------------------------
// Запросите сумму кредита
// Запросите на сколько месяцев нужно дать кредит
// Установить переменную с банковским процентом = 20% годовых
// Сделайте вывод в документ таблицей:
// Процент по кредиту: 		Х грн.
// Всего нужно будет вернуть: 	Y грн.


const summ = +prompt('Введите сумму','');
const month = +prompt('на сколько месяцев','');
const procent = 20;

let rezult = summ * procent / 100 / 12 * month;

let obj = summ + rezult;

console.log('Процент по кредиту = ', rezult.toFixed(2) + 'грн.');
console.log('Всего нужно будет вернуть = ', obj.toFixed(2) + 'грн.');












































